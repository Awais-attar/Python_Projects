                                                      #Converting Currencies
                                                          
print("READ THE INSTRUCTIONS:")
print("NOTE: AVAILABLE CURRENCIES (INDIAN: RUPEES) (US: DOLLARS) (UK:POUNDS) (EUROPE:EUROS) (JAPAN:YEN)")
print("PlEASE CHECK SPELLINGS : ('Rupees'), ('Dollars'), ('Pounds'), ('Euros'), ('Yens')")
print("CURRENCY PRICE AS PER DATE : 24-JUNE-2024")
print("*"*150)
customer_currency=input("Enter your Currency:")
Exchange=input("You want to change into which Currency:")
Money=int(input("Enter the Money:"))
print("*"*150)
                                                   #indian currency Rupees to other

                                                        #RUPEES TO DOLLARS
if customer_currency=='dollers' and  Exchange=='rupees':
          getting=Money*83.54   
          print(f"you will Withdraw {getting} Rupees ")
elif customer_currency=='Rupees' and  Exchange=='Dollers':
          getting=Money*00.12
          print(f"you will Withdraw {getting} Dollars")
                                                          # RUPEES TO POUNDS
elif customer_currency=='Rupees' and Exchange=='Pounds':
          getting=Money*0.0095  
          print(f"you will Withdraw {getting} Pounds ")
elif customer_currency=='Pounds' and Exchange=='rupees':
          getting=Money*105.62   
          print(f"you will Withdraw {getting} Rupees ")
                                                          #RUPEES TO EUROS
elif customer_currency=='Rupees' and  Exchange=='Euros':
          getting=Money*0.011 
          print(f"you will Withdraw {getting} Euros ")
elif customer_currency=='Euros' and  Exchange=='rupees':
          getting=Money*89.36 
          print(f"you will Withdraw {getting} Rupees ")
                                                          #RUPEES TO YEN
elif customer_currency=='Rupees'  and  Exchange=='Yens':
          getting=Money*1.91
          print(f"you will Withdraw {getting} YEN ")
elif customer_currency=='Yens'   and Exchange=='Rupees':
          getting=Money*0.52 
          print(f"you will Withdraw {getting} Rupees ")
                                                      #US currency Dollers to other

                                                           #DOLLERS TO POUNDS
elif customer_currency=='Dollers' and Exchange=='Pounds':
          getting=Money*0.79 
          print(f"you will Withdraw {getting} Pounds ")
elif customer_currency=='Pounds'  and  Exchange=='Dollers':
          getting=Money*1.27
          print(f"you will Withdraw {getting} Dollers")
                                                            #DOLLERS TO EUROS
elif customer_currency=='Dollers' and  Exchange=='Euros':
          getting=Money*0.93
          print(f"you will Withdraw {getting} Euros ")
elif customer_currency=='Euros' and  Exchange=='Dollers':
          getting=Money*1.07 
          print(f"you will Withdraw {getting} Dollers ")      #DOLLERS TO YEN
elif customer_currency=='Dollers'  and  Exchange=='Yens':
          getting=Money*159.71
          print(f"you will Withdraw {getting} YEN ")
elif customer_currency=='Yens'   and Exchange=='Dollers':
          getting=Money*0.0063
          print(f"you will Withdraw {getting} Dollers ")

                                                       #UK currency Pounds to other
                        
                                                            #POUNDS TO EUROS
elif customer_currency=='Pounds' and  Exchange=='Euros':
          getting=Money*1.18
          print(f"you will Withdraw {getting} Euros ")
elif customer_currency=='Euros' and  Exchange=='Pounds':
          getting=Money*0.85 
          print(f"you will Withdraw {getting} Pounds ")      #POUNDS TO YEN
elif customer_currency=='Pounds'  and  Exchange=='Yens':
          getting=Money*202.09
          print(f"you will Withdraw {getting} YEN ")
elif customer_currency=='Yens'   and Exchange=='Pounds':
          getting=Money*0.0049
          print(f"you will Withdraw {getting} Pounds ")
                                                       #Euros currency Euros to other
                        
                                                             #EUROS TO YEN
elif customer_currency=='Euros'  and  Exchange=='Yens':
          getting=Money*171.08
          print(f"you will Withdraw {getting} YEN ")
elif customer_currency=='Yens'   and Exchange=='Euros':
          getting=Money*0.0058
          print(f"you will Withdraw {getting} Euros ")
else:
    print("invalid")
