                                   # ROCK: PAPER : SCISSOR
import random
game = "WELCOME TO THE GAME"
x = game.center(150,'*')
print(x)             
print("ROCK: PAPER : SCISSOR")
user_choice=int(input("Enter your Choice [0,1,2]:"))#0.Rock 1.Paper 2.Scissor
print("Your Choice",+user_choice)
if user_choice>2:
    print("invalid input only B/W [0 to 20]") 
else:
    print('*'*150)
    computer_choice=random.randint(0,2)
    print("Computer Choice:",+computer_choice)
    if computer_choice==user_choice or user_choice==computer_choice:
        print("it's Draw")
    elif  computer_choice==0 and user_choice==2:
        print("You Lose") 
    elif  user_choice==0 and computer_choice==2:
        print("You Win") 
    elif computer_choice>user_choice:
        print("You Lose")
    elif computer_choice<user_choice:
        print("You Win") 