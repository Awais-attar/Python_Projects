                                                       #pizza task
shop = "WELCOME TO PIZZA HUB"
x = shop.center(150,'*')
print(x)                                        
size=input("which pizza do you want(S/M/L)?")                 #size of Pizza
bill=0
if size=='Small' or size=='s' or size=='small' or size=='small':
    bill+=100
    print("small size pizza")
elif size=='M' or size=='m'or size=='medium'or  size=='Medium':
    bill+=150
    print("medium size pizza")
else:
    bill+=250
    print("large size pizza")
add_pepperani=input("do you want pepperani(Y/N)?")            #Pepperani
if add_pepperani=='Y'or add_pepperani=='y':
    if size=='Small' or size=='s' or size=='small' or size=='small':
        bill+=30
    else:
        bill+=50
extra_cheese=input("do you want extra cheese(Y/N)?")          #cheese
if extra_cheese =='Y'or extra_cheese=='y':
    if size=='Small' or size=='s' or size=='small' or size=='small':
        bill+=50
    else:
        bill+=100
parcel=input("do you want parcel (Y/N)?")                     #parcel
if parcel =='Y'or parcel=='y':
   bill+=20
   print('*'*150)
   print(f"your total bill={bill}")
   print("Thank you")
else:
    print(f"your total bill={bill}")
    print("Thank you")